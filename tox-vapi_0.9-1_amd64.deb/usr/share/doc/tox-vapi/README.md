Tox VAPI
====

https://wiki.gnome.org/action/show/Projects/Vala/LegacyBindings

![ValaBot running](http://i.imgur.com/2s2Uk5K.png)

TODO:
- [x] toxcore
- [x] toxav
- [ ] <s>toxdns</s> (deprecated)
- [x] toxencryptsave
